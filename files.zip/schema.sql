-- ============================================================
--  Crypto Portfolio & Leverage Tracker — MySQL Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS crypto_tracker;
USE crypto_tracker;

-- ------------------------------------------------------------
-- 1. Users
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id      INT AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(50)  NOT NULL UNIQUE,
    email        VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role         ENUM('admin','trader') NOT NULL DEFAULT 'trader',
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- 2. Wallets  (each user can have multiple)
-- ------------------------------------------------------------
CREATE TABLE wallets (
    wallet_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT          NOT NULL,
    wallet_name  VARCHAR(100) NOT NULL,
    wallet_type  ENUM('spot','margin','futures') NOT NULL DEFAULT 'spot',
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 3. Assets  (crypto holdings inside a wallet)
-- ------------------------------------------------------------
CREATE TABLE assets (
    asset_id     INT AUTO_INCREMENT PRIMARY KEY,
    wallet_id    INT           NOT NULL,
    symbol       VARCHAR(20)   NOT NULL,   -- e.g. BTC, ETH
    quantity     DECIMAL(20,8) NOT NULL DEFAULT 0,
    avg_buy_price DECIMAL(20,8) NOT NULL DEFAULT 0,
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (wallet_id) REFERENCES wallets(wallet_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 4. Trades  (buy / sell records)
-- ------------------------------------------------------------
CREATE TABLE trades (
    trade_id     INT AUTO_INCREMENT PRIMARY KEY,
    wallet_id    INT           NOT NULL,
    symbol       VARCHAR(20)   NOT NULL,
    trade_type   ENUM('buy','sell') NOT NULL,
    quantity     DECIMAL(20,8) NOT NULL,
    price        DECIMAL(20,8) NOT NULL,
    fee          DECIMAL(20,8) NOT NULL DEFAULT 0,
    trade_date   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes        TEXT,
    FOREIGN KEY (wallet_id) REFERENCES wallets(wallet_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 5. Leverage Positions
-- ------------------------------------------------------------
CREATE TABLE leverage_positions (
    position_id      INT AUTO_INCREMENT PRIMARY KEY,
    wallet_id        INT           NOT NULL,
    symbol           VARCHAR(20)   NOT NULL,
    direction        ENUM('long','short') NOT NULL,
    leverage         DECIMAL(5,2)  NOT NULL,         -- e.g. 10.00 = 10×
    entry_price      DECIMAL(20,8) NOT NULL,
    quantity         DECIMAL(20,8) NOT NULL,
    margin_used      DECIMAL(20,8) NOT NULL,
    liquidation_price DECIMAL(20,8),
    status           ENUM('open','closed') NOT NULL DEFAULT 'open',
    opened_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
    closed_at        DATETIME,
    close_price      DECIMAL(20,8),
    realized_pnl     DECIMAL(20,8),
    FOREIGN KEY (wallet_id) REFERENCES wallets(wallet_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 6. Price Cache  (store CoinGecko snapshots)
-- ------------------------------------------------------------
CREATE TABLE price_cache (
    cache_id     INT AUTO_INCREMENT PRIMARY KEY,
    symbol       VARCHAR(20)   NOT NULL,
    price_usd    DECIMAL(20,8) NOT NULL,
    fetched_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_symbol_fetched (symbol, fetched_at)
);

-- ------------------------------------------------------------
-- Demo seed data
-- ------------------------------------------------------------
INSERT INTO users (username, email, password_hash, role) VALUES
  ('admin',  'admin@cryptotracker.com',  '$2b$12$placeholder_admin_hash',  'admin'),
  ('trader1','trader1@cryptotracker.com','$2b$12$placeholder_trader_hash', 'trader');

INSERT INTO wallets (user_id, wallet_name, wallet_type) VALUES
  (2, 'Main Spot Wallet',   'spot'),
  (2, 'Futures Account',    'futures');

INSERT INTO assets (wallet_id, symbol, quantity, avg_buy_price) VALUES
  (1, 'BTC', 0.50000000, 60000.00),
  (1, 'ETH', 4.00000000,  3000.00),
  (1, 'SOL', 20.00000000,  150.00);

INSERT INTO trades (wallet_id, symbol, trade_type, quantity, price, fee) VALUES
  (1, 'BTC', 'buy',  0.5,  60000, 15.00),
  (1, 'ETH', 'buy',  4.0,   3000,  6.00),
  (1, 'SOL', 'buy', 20.0,    150,  1.50);

INSERT INTO leverage_positions
  (wallet_id, symbol, direction, leverage, entry_price, quantity, margin_used, status) VALUES
  (2, 'BTC', 'long', 10.00, 62000.00, 0.1, 620.00, 'open'),
  (2, 'ETH', 'short', 5.00,  3200.00, 1.0, 640.00, 'open');
